"""This is the main module of the crm1 package."""

from . import autorepotools as autorepo
from . import data as datacls
from . import utils
from .types import *
